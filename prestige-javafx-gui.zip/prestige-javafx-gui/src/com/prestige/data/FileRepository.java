package com.prestige.data;

import com.prestige.model.Reservation;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FileRepository {
    private final String filename;

    public FileRepository(String filename) {
        this.filename = filename;
    }

    public void saveAll(List<Reservation> reservations) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename))) {
            out.writeObject(new ArrayList<>(reservations));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    public List<Reservation> loadAll() {
        File f = new File(filename);
        if (!f.exists()) return Collections.emptyList();
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(f))) {
            Object o = in.readObject();
            return (List<Reservation>) o;
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }
}
