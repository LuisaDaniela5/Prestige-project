package com.prestige.ui;

import com.prestige.data.FileRepository;
import com.prestige.model.Client;
import com.prestige.model.Reservation;
import com.prestige.model.ServiceItem;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.util.List;
import java.util.stream.Collectors;

public class MainApp extends Application {

    private final FileRepository repo = new FileRepository("reservations.dat");
    private final ObservableList<Reservation> reservations = FXCollections.observableArrayList();

    private ListView<String> listView;

    @Override
    public void start(Stage primaryStage) {
        // Load data
        List<Reservation> loaded = repo.loadAll();
        reservations.addAll(loaded);

        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));

        listView = new ListView<>();
        refreshListView();
        root.setCenter(listView);

        GridPane form = new GridPane();
        form.setHgap(8);
        form.setVgap(8);
        form.setPadding(new Insets(8));

        TextField nameField = new TextField();
        TextField emailField = new TextField();
        TextField dateField = new TextField();
        TextField serviceNameField = new TextField();
        TextField priceField = new TextField();

        form.add(new Label("Client name:"), 0, 0);
        form.add(nameField, 1, 0);
        form.add(new Label("Email:"), 0, 1);
        form.add(emailField, 1, 1);
        form.add(new Label("Date (YYYY-MM-DD):"), 0, 2);
        form.add(dateField, 1, 2);
        form.add(new Label("Service name:"), 0, 3);
        form.add(serviceNameField, 1, 3);
        form.add(new Label("Price:"), 0, 4);
        form.add(priceField, 1, 4);

        Button addBtn = new Button("Add reservation");
        Button saveBtn = new Button("Save to file");

        form.add(addBtn, 0, 5);
        form.add(saveBtn, 1, 5);

        addBtn.setOnAction(e -> {
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            String date = dateField.getText().trim();
            String sName = serviceNameField.getText().trim();
            double price = 0.0;
            try {
                price = Double.parseDouble(priceField.getText().trim());
            } catch (Exception ex) {
                // ignore, keep 0.0
            }
            if (name.isEmpty() || email.isEmpty() || date.isEmpty() || sName.isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Please fill all fields (price can be 0)", ButtonType.OK);
                alert.showAndWait();
                return;
            }
            Client client = new Client(name, email);
            ServiceItem service = new ServiceItem(sName, price);
            Reservation r = new Reservation(client, date);
            r.addService(service);
            reservations.add(r);
            refreshListView();

            // clear fields
            nameField.clear(); emailField.clear(); dateField.clear(); serviceNameField.clear(); priceField.clear();
        });

        saveBtn.setOnAction(e -> {
            repo.saveAll(reservations);
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Saved " + reservations.size() + " reservations.", ButtonType.OK);
            alert.showAndWait();
        });

        root.setRight(form);

        Scene scene = new Scene(root, 800, 420);
        primaryStage.setTitle("Prestige — Mini GUI (Workshop 4)");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void refreshListView() {
        List<String> texts = reservations.stream()
                .map(r -> r.getClient().getName() + " — " + r.getDate() + " — $" + r.getTotalPrice())
                .collect(Collectors.toList());
        listView.setItems(FXCollections.observableArrayList(texts));
    }

    @Override
    public void stop() {
        // save on close
        repo.saveAll(reservations);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
