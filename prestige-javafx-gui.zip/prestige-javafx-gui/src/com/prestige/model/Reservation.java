package com.prestige.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Reservation implements Serializable {
    private static final long serialVersionUID = 1L;
    private Client client;
    private String date;
    private List<ServiceItem> services = new ArrayList<>();

    public Reservation(Client client, String date) {
        this.client = client;
        this.date = date;
    }

    public void addService(ServiceItem s) { services.add(s); }
    public Client getClient() { return client; }
    public String getDate() { return date; }
    public List<ServiceItem> getServices() { return services; }
    public double getTotalPrice() {
        return services.stream().mapToDouble(ServiceItem::getPrice).sum();
    }
}
