# Prestige — Minimal JavaFX GUI (Workshop 4)

Archivos incluidos:
- src/com/prestige/ui/MainApp.java  (JavaFX Application)
- src/com/prestige/model/*.java     (model classes, Serializable)
- src/com/prestige/data/FileRepository.java (simple file persistence)
- .vscode/launch.json (configured with your javafx-sdk path)

## Cómo usar en VS Code
1. Asegúrate de tener JDK 17+ instalado and Java Extension Pack.
2. La VM args en .vscode/launch.json ya apunta a:
   `C:\Users\Usuario\Downloads\javafx-sdk-25.0.1\lib`
3. Compila y ejecuta desde VS Code usando la configuración "Launch Prestige Main".

## Notas sobre errores comunes
- Si ves errores sobre módulos JavaFX: revisa que la ruta (--module-path) esté correcta y que `java --version` sea 17+.
- Si usas JDK empaquetado por vendors (Adoptium, Azul, Oracle) y tienes problemas, prueba con otra distribución JDK 17+.
- Si aparecen errores de paquetes, verifica que las rutas de los archivos coincidan con los `package` en las clases.
